module.exports = {
  "TRANSLATION_EN_GB": {
    "WELCOME_MSG": 'Welcome to the inquiry system, do you want to do the inquiry?  say yes to do the inquiry or no to quit.',
    "BYE": 'OK, See you next time',
    "YES": 'OK, You mean Yes',
    "NO": 'OK, You mean No',
    "FIRST_ERROR":  'Sorry, I didn\'t get that. Try saying again the question.',
    "SECOND_ERROR": 'Sorry, I still didn\'t get that.'+'Please ask me another question.',
    "UNHANDLED": 'Say yes to continue, or no to end the game.'
  }
};
